// Função para exibir os ícones em locais aleatórios

